```python




format_action = {
    self.action_subscript: self.text_formatter_subscript, 
    self.action_superscript: self.text_formatter_superscript, 
    self.action_bold: self.text_formatter_bold, 
    self.action_italic: self.text_formatter_italic,
    self.action_underline: self.text_formatter_underline,
    self.action_strikethrough: self.text_formatter_strikethrough,
    self.action_increase_font_size: self.text_formatter_increase_font,
    self.action_decrease_font_size: self.text_formatter_decrease_font_size,
    self.action_highlight: self.text_formatter_highlight,
    self.action_color: self.text_formatter_color,
}

alignment_action = {
        self.action_center: self.center_text,
    self.action_right_align: self.right_align_text,
    self.action_left_align: self.left_align_text,
    self.action_justify: self.justify_text,
}

for action, formatter in format_action.items():
    self.action.triggered.connect(lambda: apply_current_text_format(formatter))

for align_action, alignment in alignment_action.items():
    self.action.triggered.connect(lambda: apply_current_text_alignment(alignment))
```


text_formatter_color
text_formatter_bold
text_formatter_strikethrough
text_formatter_decrease_font_size
text_formatter_increase_font
text_formatter_highlight
text_formatter_italic
text_formatter_underline
text_formatter_subscript

TextFormatCenter
TextFormatRightAlign
TextFormatAlignLeft
TextFormatJustify
